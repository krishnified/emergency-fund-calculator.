# KRISHNIFIED Emergency Fund Calculator — Blue Edition

This is the updated white-and-blue version of the KRISHNIFIED Emergency Fund Calculator, including a pound money-bag icon and responsive layout.

## Replace the current website on GitHub Pages

1. Download and extract this ZIP.
2. Open https://github.com/krishnified/emergency-fund-calculator
3. Open `index.html`.
4. Tap the pencil/Edit button.
5. Select all existing code in the editor and replace it with the complete contents of the new `index.html` from this ZIP. On mobile, if editing the full file is difficult, return to the repository and use **Add file → Upload files** to upload this new `index.html`; GitHub should ask to confirm replacing the existing file.
6. Commit the change to the `main` branch.
7. GitHub Pages will redeploy automatically. Refresh the public website after a minute or two:
   https://krishnified.github.io/emergency-fund-calculator/

The website is a single HTML file; no build step or extra dependencies are required.
