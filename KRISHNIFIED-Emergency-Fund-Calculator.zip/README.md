# KRISHNIFIED Emergency Fund Calculator

A responsive, single-page emergency fund calculator with a premium dark theme. It uses plain HTML, CSS, and JavaScript, so there is no build step, server, API key, or paid hosting required.

## Files
- `index.html` — the complete working website.
- `README.md` — these publishing instructions.

## Publish free with GitHub Pages

1. Sign in or create a free account at https://github.com/.
2. Create a **new public repository** named `emergency-fund-calculator`.
3. On your computer, extract this ZIP file.
4. Open the new repository on GitHub and choose **Add file → Upload files**.
5. Upload `index.html` (and optionally `README.md`) from this folder. Commit the upload to the `main` branch.
6. Open the repository's **Settings → Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**.
8. Select branch **main** and folder **/(root)**, then click **Save**.
9. Wait a minute or two, then refresh the Pages settings. GitHub will show the published website link. It should look like:
   `https://YOUR-GITHUB-USERNAME.github.io/emergency-fund-calculator/`
10. Open the link on your phone and test the calculator. Share that URL in your Instagram bio, WhatsApp, or other profiles.

## To use a shorter URL
Your GitHub username forms part of the URL. If you want a URL like `https://krishnified.github.io/`, create a repository named exactly `krishnified.github.io` (only if that username is yours/available) and upload `index.html` to that repository. Otherwise, use the project URL above.

## Custom domain (optional)
You can connect a domain you own later from **Settings → Pages → Custom domain**. Domain registration normally costs money; GitHub Pages hosting itself can be free.

## Important notes
- The sample figures are just defaults; visitors should enter their own expenses, savings, and contribution.
- This is an educational estimate, not financial advice. The calculator runs in the visitor's browser and does not send their inputs to a server.
- The website currently uses the KRISHNIFIED wordmark as text plus a simple K icon. Replace those in `index.html` if you have an official logo.
